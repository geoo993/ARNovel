hello "maj@" 
this is the first model to get on if you excuse the formatting errors. 
already left me pretty texturing job and some things can be improved.

